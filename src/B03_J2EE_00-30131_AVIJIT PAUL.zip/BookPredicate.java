@FunctionalInterface
public interface BookPredicate {
    boolean test (Book book);
}
